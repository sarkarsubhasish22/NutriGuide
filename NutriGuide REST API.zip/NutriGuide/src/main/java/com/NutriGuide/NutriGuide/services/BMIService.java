package com.NutriGuide.NutriGuide.services;

import com.NutriGuide.NutriGuide.entities.BMI;

public interface BMIService {

	public BMI addBMI(BMI bmi);
	
	
}
