package com.NutriGuide.NutriGuide.services;

import com.NutriGuide.NutriGuide.entities.CC;

public interface CCService {

	public CC addCC(CC cc);
	
	
}
