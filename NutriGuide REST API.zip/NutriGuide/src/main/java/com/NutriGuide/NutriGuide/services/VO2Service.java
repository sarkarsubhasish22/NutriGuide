package com.NutriGuide.NutriGuide.services;

import com.NutriGuide.NutriGuide.entities.VO2;

public interface VO2Service {

	public VO2 addVO2(VO2 vo2);
}
