package com.NutriGuide.NutriGuide.services;

import com.NutriGuide.NutriGuide.entities.PFI;

public interface PFIService {

	public PFI addPFI(PFI pfi);
}
