package com.NutriGuide.NutriGuide.entities;

public enum Status {

	SUCCESS,
    USER_ALREADY_EXISTS,
    FAILURE
}
