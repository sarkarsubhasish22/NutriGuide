package com.NutriGuide.NutriGuide.services;

import com.NutriGuide.NutriGuide.entities.MUAC;

public interface MUACService {

	public MUAC addMUAC(MUAC muac);
	
	
}
