package com.NutriGuide.NutriGuide.services;

import com.NutriGuide.NutriGuide.entities.MDD;

public interface MDDService {

	public MDD addMDD(MDD mdd);
	
	
}
