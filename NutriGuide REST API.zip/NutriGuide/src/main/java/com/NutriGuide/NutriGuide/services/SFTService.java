package com.NutriGuide.NutriGuide.services;

import com.NutriGuide.NutriGuide.entities.SFT;

public interface SFTService {

	public SFT addSFT(SFT sft);
}
