package com.NutriGuide.NutriGuide;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NutriGuideApplication {

	public static void main(String[] args) {
		SpringApplication.run(NutriGuideApplication.class, args);
	}

}
